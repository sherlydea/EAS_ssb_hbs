<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PublicController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\PendaftaranController;
use App\Http\Controllers\SiswaDashboardController;
use App\Http\Controllers\SiswaTurnamenController;
use App\Http\Controllers\AdminPendaftaranController;
use App\Http\Controllers\AdminDashboardController;
use App\Http\Controllers\SiswaController;


/*
|--------------------------------------------------------------------------
| Web Routes - SSB HBS
|--------------------------------------------------------------------------
| Berisi seluruh route aplikasi:
| - Landing Page
| - Login & Logout
| - Pendaftaran Siswa
| - Dashboard Siswa
| - Dashboard Admin
| - Dashboard Pelatih
| - Turnamen
|--------------------------------------------------------------------------
*/


/*
|--------------------------------------------------------------------------
| HALAMAN PUBLIK
|--------------------------------------------------------------------------
*/

// Landing page
Route::get('/', [PublicController::class, 'index'])
    ->name('home');

// Login
Route::get('/login', [AuthController::class, 'showLogin'])
    ->name('login');

Route::post('/login', [AuthController::class, 'login'])
    ->name('login.process');

// Logout
Route::post('/logout', [AuthController::class, 'logout'])
    ->name('logout');


/*
|--------------------------------------------------------------------------
| PENDAFTARAN SISWA
|--------------------------------------------------------------------------
| Calon siswa mengisi form dan mengupload dokumen
|--------------------------------------------------------------------------
*/

Route::get('/pendaftaran', [PendaftaranController::class, 'create'])
    ->name('pendaftaran.create');

Route::post('/pendaftaran', [PendaftaranController::class, 'store'])
    ->name('pendaftaran.store');


/*
|--------------------------------------------------------------------------
| DASHBOARD SISWA
|--------------------------------------------------------------------------
| Seluruh fitur yang hanya bisa diakses siswa login
|--------------------------------------------------------------------------
*/

Route::middleware(['auth'])
    ->prefix('siswa')
    ->name('siswa.')
    ->group(function () {

        /*
        |--------------------------------------------------------------------------
        | Dashboard & Profil
        |--------------------------------------------------------------------------
        */

        Route::get('/dashboard', [SiswaDashboardController::class, 'index'])
            ->name('dashboard');

        Route::get('/profil', [SiswaDashboardController::class, 'profil'])
            ->name('profil');


        /*
        |--------------------------------------------------------------------------
        | Jadwal Latihan & Turnamen
        |--------------------------------------------------------------------------
        */

        Route::get('/jadwal-latihan', [SiswaDashboardController::class, 'jadwalLatihan'])
            ->name('jadwal-latihan');

        Route::get('/jadwal-turnamen', [SiswaDashboardController::class, 'jadwalTurnamen'])
            ->name('jadwal-turnamen');


        /*
        |--------------------------------------------------------------------------
        | Pembayaran SPP
        |--------------------------------------------------------------------------
        */

        Route::get('/pembayaran', [SiswaDashboardController::class, 'pembayaran'])
            ->name('pembayaran');

        Route::post('/pembayaran/upload', [SiswaDashboardController::class, 'uploadPembayaran'])
            ->name('pembayaran.upload');

        Route::get('/riwayat-pembayaran', [SiswaDashboardController::class, 'riwayatPembayaran'])
            ->name('riwayat-pembayaran');


        /*
        |--------------------------------------------------------------------------
        | Pemesanan Jersey
        |--------------------------------------------------------------------------
        */

        Route::get('/jersey', [SiswaDashboardController::class, 'jersey'])
            ->name('jersey');

        Route::post('/jersey/pesan', [SiswaDashboardController::class, 'pesanJersey'])
            ->name('jersey.pesan');

        Route::post('/jersey/upload/{id}', [SiswaDashboardController::class, 'uploadBuktiJersey'])
            ->name('jersey.upload');


        /*
        |--------------------------------------------------------------------------
        | Riwayat Absensi
        |--------------------------------------------------------------------------
        */

        Route::get('/riwayat-absensi', [SiswaDashboardController::class, 'riwayatAbsensi'])
            ->name('riwayat-absensi');
    });


/*
|--------------------------------------------------------------------------
| ADMIN
|--------------------------------------------------------------------------
| Admin mengelola pendaftaran siswa
|--------------------------------------------------------------------------
*/

Route::middleware(['auth'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {

        /*
        |--------------------------------------------------------------------------
        | Dashboard Admin
        |--------------------------------------------------------------------------
        */

        Route::get('/dashboard', [AdminDashboardController::class, 'index'])
            ->name('dashboard');


        /*
        |--------------------------------------------------------------------------
        | Manajemen Pendaftaran
        |--------------------------------------------------------------------------
        */

        // List pendaftaran
        Route::get('/pendaftaran', [AdminPendaftaranController::class, 'index'])
            ->name('pendaftaran');

        // Detail pendaftaran
        Route::get('/pendaftaran/{id}', [AdminPendaftaranController::class, 'show'])
            ->name('pendaftaran.show');

        // Terima siswa
        Route::post('/pendaftaran/{id}/terima', [AdminPendaftaranController::class, 'terima'])
            ->name('pendaftaran.terima');

        // Tolak siswa
        Route::post('/pendaftaran/{id}/tolak', [AdminPendaftaranController::class, 'tolak'])
            ->name('pendaftaran.tolak');
    });

/*
        |--------------------------------------------------------------------------
        | Data Siswa
        |--------------------------------------------------------------------------
        */

    Route::middleware(['auth'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {
        Route::get('/siswas', [SiswaController::class, 'index'])->name('siswas.index');
        Route::get('/siswas/{id}', [SiswaController::class, 'show'])->name('siswa.show');
    });


/*
|--------------------------------------------------------------------------
| PELATIH
|--------------------------------------------------------------------------
| Sementara masih placeholder
|--------------------------------------------------------------------------
*/

Route::middleware(['auth'])
    ->get('/pelatih/dashboard', function () {
        return 'Dashboard Pelatih - bagian anggota 3';
    })
    ->name('pelatih.dashboard');


/*
|--------------------------------------------------------------------------
| TURNAMEN SISWA
|--------------------------------------------------------------------------
*/

Route::get('/siswa/jadwal-turnamen', [SiswaTurnamenController::class, 'index'])
    ->name('siswa.jadwal-turnamen');

Route::post('/siswa/turnamen/upload/{id}', [SiswaTurnamenController::class, 'uploadBukti'])
    ->name('siswa.turnamen.upload');
