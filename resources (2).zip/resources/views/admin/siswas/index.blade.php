@extends('admin.layouts.app')

@section('content')

<style>
/* ===============================
   HEADER HALAMAN
   Identitas dan deskripsi halaman
================================ */
.page-label{
    color:#D4AF37;
    font-size:13px;
    letter-spacing:3px;
    text-transform:uppercase;
    margin-bottom:12px;
}
.page-title{
    font-size:42px;
    font-weight:700;
    color:#1A2238;
    margin-bottom:10px;
}
.page-desc{
    color:#555;
    max-width:750px;
    line-height:1.8;
    margin-bottom:35px;
}

/* ===============================
   BANNER STATISTIK VERIFIKASI
================================ */
.verify-banner{
    background:#3D000A;
    color:white;
    border-radius:24px;
    padding:28px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:35px;
}
.verify-count{
    font-size:34px;
    font-weight:700;
}
.verify-desc{
    margin-top:5px;
    opacity:.9;
}
.verify-btn{
    background:#D4AF37;
    color:black;
    text-decoration:none;
    padding:14px 28px;
    border-radius:999px;
    font-weight:600;
}

/* ===============================
   KARTU STATISTIK
================================ */
.stats-grid{
    display:grid;
    grid-template-columns:repeat(5,1fr);
    gap:20px;
    margin-bottom:40px;
}
.stat-card{
    background:white;
    border-radius:20px;
    padding:24px;
    box-shadow:0 4px 10px rgba(0,0,0,.05);
}
.stat-title{
    font-size:13px;
    text-transform:uppercase;
    color:#888;
    margin-bottom:10px;
}
.stat-value{
    font-size:42px;
    font-weight:700;
}

/* ===============================
   FILTER & SEARCH
================================ */
.filter-card{
    background:white;
    border-radius:24px;
    padding:25px;
    margin-bottom:30px;
}
.search-form{
    display:flex;
    gap:16px;
    margin-bottom:20px;
}
.search-box{
    flex:1;
    height:56px;
    border:1px solid #ddd;
    border-radius:999px;
    padding:0 20px;
    font-size:15px;
}
.search-button{
    height:56px;
    padding:0 28px;
    border:none;
    border-radius:999px;
    background:#7A1025;
    color:white;
    font-weight:700;
    cursor:pointer;
}
.search-button:hover{
    background:#5e0d1d;
}
.status-tabs{
    display:flex;
    gap:30px;
}
.status-tabs a{
    text-decoration:none;
    color:#666;
    font-weight:500;
    padding-bottom:10px;
    border-bottom:2px solid transparent;
}
.status-tabs a.active{
    color:#111827;
    font-weight:700;
    border-bottom:2px solid #7A1025;
}

/* ===============================
   TABEL DATA SISWA
================================ */
.table-card{
    background:white;
    border-radius:24px;
    overflow:hidden;
    box-shadow:0 4px 10px rgba(0,0,0,.05);
}
.table-card table{
    width:100%;
    border-collapse:collapse;
}
.table-card th{
    background:#F8F5EE;
    padding:18px;
    text-align:left;
    font-size:14px;
}
.table-card td{
    padding:18px;
    border-top:1px solid #eee;
}
.status-badge{
    padding:6px 12px;
    border-radius:999px;
    font-size:12px;
    font-weight:600;
}
.status-pending{ background:#FFF3CD; color:#856404; }
.status-diterima{ background:#D4EDDA; color:#155724; }
.status-ditolak{ background:#F8D7DA; color:#721C24; }

.detail-btn{
    border:none;
    background:#7A1025;
    color:white;
    padding:8px 16px;
    border-radius:10px;
    cursor:pointer;
}

/* ===============================
   SUMMARY & PAGINATION CUSTOM
================================ */
.table-summary{
    text-align:center;
    margin-bottom:12px;
    color:#4B5563;
    font-size:14px;
}

.pagination-container{
    display:flex;
    justify-content:center;
    align-items:center;
    margin-bottom:24px;
}

.pagination{
    display:flex;
    align-items:center;
    gap:8px;
    padding:12px 18px;
    border-radius:16px;
}
.pagination a,
.pagination span{
    width:34px;
    height:34px;
    display:flex;
    align-items:center;
    justify-content:center;
    border-radius:10px;
    text-decoration:none;
    font-weight:600;
    font-size:14px;
    transition:.2s;
}
.pagination a{
    color:#1A2238;
    background:transparent;
}
.pagination a:hover{
    background:#F5EFE7;
}
.pagination .active{
    background:#650018;
    color:white;
    font-weight:700;
}
.pagination .arrow{
    font-size:18px;
    color:#650018;
    font-weight:700;
}
.pagination span:not(.active){
    background:transparent;
}

@media(max-width:1100px) { .stats-grid { grid-template-columns:repeat(2,1fr); } }
@media(max-width:700px) { 
    .verify-banner { flex-direction:column; align-items:flex-start; gap:20px; } 
    .stats-grid { grid-template-columns:1fr; } 
}
</style>

{{-- ===============================
   HEADER HALAMAN
================================ --}}
<div class="page-label">Data Siswa</div>
<h1 class="page-title">Manajemen Data Siswa</h1>
<p class="page-desc">Kelola seluruh data siswa aktif SSB HBS yang telah terverifikasi dan terdaftar dalam sistem.</p>

{{-- ===============================
   TABEL DATA SISWA
================================ --}}
<div class="table-card">
    <div class="table-wrapper">
        <table class="table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Siswa</th>
                    <th>Kategori</th>
                    <th>Nomor HP</th>
                    <th>Tanggal Daftar</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($siswas as $item)
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>{{ $item->nama }}</td>
                        <td>{{ $item->kategori_latihan }}</td>
                        <td>{{ $item->no_hp }}</td>
                        <td>{{ \Carbon\Carbon::parse($item->tanggal_daftar)->format('d M Y') }}</td>
                        <td>
                            <span class="status-badge status-{{ strtolower($item->status_verifikasi) }}">
                                {{ ucfirst($item->status_verifikasi) }}
                            </span>
                        </td>
                        <td>
                            <a href="{{ route('admin.siswa.show', $item->id) }}" class="detail-btn">Detail</a>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="7" style="text-align:center;">Tidak ada data siswa.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    {{-- ===============================
         SUMMARY DAN PAGINATION
    ================================= --}}
    <div style="padding:20px 24px 28px;">

        <p class="table-summary">
            Menampilkan {{ $siswas->firstItem() ?? 0 }} 
            - {{ $siswas->lastItem() ?? 0 }} dari {{ $siswas->total() ?? 0 }} siswa
        </p>

        <div class="pagination-container">
            @if ($siswas->lastPage() > 1)
                <div class="pagination">
                    {{-- Previous --}}
                    @if ($siswas->onFirstPage())
                        <span class="arrow">&#8249;</span>
                    @else
                        <a class="arrow" href="{{ $siswas->previousPageUrl() }}">&#8249;</a>
                    @endif

                    {{-- Page Numbers --}}
                    @for ($i = 1; $i <= $siswas->lastPage(); $i++)
                        @if ($i == $siswas->currentPage())
                            <span class="active">{{ $i }}</span>
                        @else
                            <a href="{{ $siswas->url($i) }}">{{ $i }}</a>
                        @endif
                    @endfor

                    {{-- Next --}}
                    @if ($siswas->hasMorePages())
                        <a class="arrow" href="{{ $siswas->nextPageUrl() }}">&#8250;</a>
                    @else
                        <span class="arrow">&#8250;</span>
                    @endif
                </div>
            @endif
        </div>

    </div>
</div>

@endsection