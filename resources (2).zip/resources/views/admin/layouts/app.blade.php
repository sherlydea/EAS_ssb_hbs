<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin SSB HBS</title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:'Poppins',sans-serif;
        }

        body{
            background:#F5F1E8;
            color:#1f2937;
        }

        .topbar{
            background:#1a0b0f;
            color:white;

            display:flex;
            justify-content:space-between;
            align-items:center;

            padding:16px 24px;

            border-bottom:1px solid rgba(122,16,37,.3);
            box-shadow:0 2px 10px rgba(0,0,0,.15);
        }

        .logo-section{
            display:flex;
            align-items:center;
            gap:15px;
        }

        .logo-img{
            width:48px;
            height:56px;
            border-radius:0;
            object-fit:contain;
        }

        .logo-title{
            font-size:20px;
            font-weight:800;
            line-height:1;
            color:#ffffff;
        }

        .logo-title .logo-highlight{
            color:#d4af37;
        }

        .logo-sub{
            font-size:12px;
            color:rgba(255,255,255,.45);
            margin-top:4px;
        }

        .admin-info{
            display:flex;
            align-items:center;
            gap:15px;
        }

        .avatar{
            width:40px;
            height:40px;
            border-radius:50%;
            background:#D4AF37;
        }

        .menu-toggle{
            width:48px;
            height:48px;
            border-radius:18px;
            background:#7a1025;
            border:1px solid rgba(212,175,55,.3);
            display:flex;
            align-items:center;
            justify-content:center;
            gap:6px;
            flex-direction:column;
            cursor:pointer;
            transition:.25s;
        }

        .menu-toggle:hover{
            background:#600018;
            border-color:rgba(212,175,55,.7);
        }

        .menu-toggle span{
            width:20px;
            height:2px;
            background:#d4af37;
            border-radius:999px;
            display:block;
        }

        .container{
            max-width:1400px;
            margin:auto;
            padding:40px;
        }

        /* ==========================
           OVERLAY
        ========================== */

        .overlay{
            position:fixed;
            top:0;
            left:0;

            width:100%;
            height:100%;

            background:rgba(0,0,0,.4);

            opacity:0;
            visibility:hidden;

            transition:.3s;

            z-index:998;
        }

        .overlay.active{
            opacity:1;
            visibility:visible;
        }

        /* =========================
           SIDEBAR ADMIN
        ========================= */

        .sidebar{
            position:fixed;
            top:0;
            right:-340px;

            width:340px;
            height:100vh;

            background:#fff8e7;

            transition:.3s ease;

            z-index:9999;

            display:flex;
            flex-direction:column;

            box-shadow:-8px 0 20px rgba(0,0,0,.15);
        }

        .sidebar.active{
            right:0;
        }

        /* HEADER SIDEBAR */

        .sidebar-top{
            background:#1a0b0f;
            padding:24px;
        }

        .sidebar-title{
            font-size:22px;
            font-weight:700;
            color:white;
        }

        .sidebar-subtitle{
            margin-top:8px;
            color:rgba(255,255,255,.75);
            font-size:12px;
        }

        .close-btn{
            position:absolute;
            top:25px;
            right:25px;

            font-size:28px;
            color:#d4af37;

            cursor:pointer;
        }

        /* BODY SIDEBAR */

        .sidebar-menu{
            flex:1;
            padding:26px;
            overflow-y:auto;
        }

        .sidebar-menu a{
            display:flex;
            align-items:center;

            height:54px;

            padding:0 16px;

            text-decoration:none;

            color:#1a0b0f;

            background:#fffaf0;

            border:1px solid rgba(122,16,37,.22);

            border-radius:18px;

            font-size:14px;
            font-weight:600;

            margin-bottom:10px;

            transition:.25s;
        }

        /* HOVER */

        .sidebar-menu a:hover{
            background:#7a1025;
            border-color:#600018;
            color:#fff8e7;
            transform:translateX(-4px);
        }

        /* ACTIVE */

        .sidebar-menu a.active{
            background:#fffaf0;
            color:#1a0b0f;
            border-color:rgba(122,16,37,.22);
        }

        /* HOVER SAAT ACTIVE */

        .sidebar-menu a.active:hover{
            background:#7a1025;
            border-color:#600018;
            color:#fff8e7;
        }

        /* FOOTER */

        .sidebar-footer{
            padding:24px;
            border-top:1px solid rgba(122,16,37,.2);
            background:#fff8e7;
        }

        .logout-btn{
            width:100%;

            height:54px;

            border:none;

            border-radius:18px;

            background:#9b072a;

            color:white;

            font-size:14px;
            font-weight:700;

            cursor:pointer;

            transition:.25s;
        }

        .logout-btn:hover{
            background:#600018;
        }

    </style>

</head>
<body>

<div id="overlay" class="overlay" onclick="toggleSidebar()"></div>

<div class="topbar">

    <div class="logo-section">

        <img src="{{ asset('images/loho-hbs.png') }}" alt="Logo HBS" class="logo-img" />

        <div>
            <div class="logo-title">SSB <span class="logo-highlight">HBS</span></div>
            <div class="logo-sub">PORTAL ADMIN</div>
        </div>

    </div>

    <div class="admin-info">

        <div>
            <div style="font-size:13px">Administrator</div>
            <div style="font-size:11px">Super Admin Access</div>
        </div>

        <div class="avatar"></div>

        <button type="button" class="menu-toggle" onclick="toggleSidebar()">
            <span></span>
            <span></span>
            <span></span>
        </button>

    </div>

</div>

<div id="sidebar" class="sidebar">

    <div class="sidebar-top">
        <div class="sidebar-title">Menu Admin</div>
        <div class="sidebar-subtitle">Akses fitur administrasi SSB HBS</div>

        <span class="close-btn" onclick="toggleSidebar()">
            ×
        </span>
    </div>

    <div class="sidebar-menu">
        <a
            href="{{ route('admin.dashboard') }}"
            class="{{ request()->routeIs('admin.dashboard') ? 'active' : '' }}"
        >
            Dashboard
        </a>

        <a
            href="{{ route('admin.pendaftaran') }}"
            class="{{ request()->routeIs('admin.pendaftaran') ? 'active' : '' }}"
        >
            Pendaftaran
        </a>

        <a href="#">
            Data Siswa
        </a>

        <a href="#">
            Data Pelatih
        </a>

        <a href="#">
            Jadwal Latihan
        </a>

        <a href="#">
            Turnamen
        </a>

        <a href="#">
            Pembayaran SPP
        </a>

        <a href="#">
            Jersey
        </a>

        <a href="#">
            Report
        </a>
    </div>

    <div class="sidebar-footer">
        <form method="POST" action="{{ route('logout') }}">
            @csrf

            <button type="submit" class="logout-btn">
                Logout
            </button>
        </form>
    </div>

</div>

<div class="container">

    @yield('content')

</div>

<script>

function toggleSidebar()
{
    document
        .getElementById('sidebar')
        .classList
        .toggle('active');

    document
        .getElementById('overlay')
        .classList
        .toggle('active');
}

</script>

</body>
</html>