<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Siswa; // pastikan model Siswa sudah ada

class SiswaController extends Controller
{
    // Halaman daftar siswa
    public function index(Request $request)
    {
        $siswas = Siswa::query()
            ->when($request->search, function($q) use($request){
                $q->where('nama', 'like', "%{$request->search}%")
                  ->orWhere('no_hp', 'like', "%{$request->search}%");
            })
            ->paginate(10); // pagination 10 per halaman

        return view('admin.siswas.index', compact('siswas'));
    }

    // Detail siswa
    public function show($id)
    {
        $siswa = Siswa::findOrFail($id);
        return view('admin.siswas.show', compact('siswa'));
    }
}