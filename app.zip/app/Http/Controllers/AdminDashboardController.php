<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;

class AdminDashboardController extends Controller
{
    public function index()
    {
        $totalSiswa = DB::table('siswas')->count();

        $totalPelatih = DB::table('pelatihs')->count();

        $totalTurnamen = DB::table('turnamens')->count();

        $totalPembayaran = DB::table('pembayarans')->count();

        $totalPendaftaranPending = DB::table('pendaftarans')
            ->where('status', 'pending')
            ->count();

        $totalSPPMenunggu = DB::table('tagihan_spps')
            ->where('status', 'Menunggu Verifikasi')
            ->count();

        $pendaftaranTerbaru = DB::table('pendaftarans')
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();

        $pembayaranTerbaru = DB::table('pembayarans')
            ->join('siswas', 'pembayarans.siswa_id', '=', 'siswas.id')
            ->select(
                'siswas.nama',
                'pembayarans.jumlah',
                'pembayarans.status'
            )
            ->latest('pembayarans.created_at')
            ->take(5)
            ->get();

        $siswaPerKategori = DB::table('siswas')
            ->select('kategori_latihan', DB::raw('COUNT(*) as total'))
            ->groupBy('kategori_latihan')
            ->orderBy('kategori_latihan')
            ->get();

        $statusPendaftaran = DB::table('pendaftarans')
            ->select('status', DB::raw('COUNT(*) as total'))
            ->groupBy('status')
            ->get();

        return view('admin.dashboard', compact(
            'totalSiswa',
            'totalPelatih',
            'totalTurnamen',
            'totalPembayaran',
            'totalPendaftaranPending',
            'totalSPPMenunggu',
            'pendaftaranTerbaru',
            'pembayaranTerbaru',
            'siswaPerKategori',
            'statusPendaftaran'
        ));
    }
}