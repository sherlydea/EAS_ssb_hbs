<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminPendaftaranController extends Controller
{
    /**
     * Menampilkan seluruh data pendaftaran
     */
    public function index(Request $request)
    {
        $query = DB::table('pendaftarans');

        // Search nama atau email
        if ($request->search) {
            $query->where(function ($q) use ($request) {
                $q->where('nama', 'like', '%' . $request->search . '%')
                  ->orWhere('email', 'like', '%' . $request->search . '%');
            });
        }

        // Filter status
        if ($request->status && $request->status != 'semua') {
            $query->where('status', $request->status);
        }

        $pendaftarans = $query
        ->latest()
        ->paginate(10)
        ->withQueryString();

        return view('admin.pendaftaran.index', [
            'pendaftarans'      => $pendaftarans,
            'totalPendaftaran'  => DB::table('pendaftarans')->count(),
            'totalPending'      => DB::table('pendaftarans')->where('status', 'pending')->count(),
            'totalDiterima'     => DB::table('pendaftarans')->where('status', 'diterima')->count(),
            'totalDitolak'      => DB::table('pendaftarans')->where('status', 'ditolak')->count(),
        ]);
    }

    /**
     * Detail pendaftaran
     */
    public function show($id)
    {
        $pendaftaran = DB::table('pendaftarans')
            ->where('id', $id)
            ->first();

        return view('admin.pendaftaran.show', compact('pendaftaran'));
    }

    /**
     * Terima pendaftaran siswa
     */
    public function terima($id)
    {
        $pendaftaran = DB::table('pendaftarans')
            ->where('id', $id)
            ->first();

        if (!$pendaftaran) {
            return redirect()
                ->route('admin.pendaftaran')
                ->with('error', 'Data pendaftaran tidak ditemukan.');
        }

        // Cegah siswa masuk dua kali
        $sudahAda = DB::table('siswas')
            ->where('nama', $pendaftaran->nama)
            ->where('tanggal_lahir', $pendaftaran->tanggal_lahir)
            ->exists();

        if (!$sudahAda) {

            /*
            |--------------------------------------------------------------------------
            | Memindahkan data dari tabel pendaftarans ke tabel siswas
            |--------------------------------------------------------------------------
            */

            DB::table('siswas')->insert([
                'nama'               => $pendaftaran->nama,
                'tempat_lahir'       => $pendaftaran->tempat_lahir,
                'tanggal_lahir'      => $pendaftaran->tanggal_lahir,
                'jenis_kelamin'      => $pendaftaran->jenis_kelamin,
                'kategori_latihan'   => $pendaftaran->kategori_latihan,
                'no_hp'              => $pendaftaran->no_hp,
                'nama_orang_tua'     => $pendaftaran->nama_orang_tua,
                'alamat'             => $pendaftaran->alamat,
                'foto_siswa'         => $pendaftaran->foto_siswa,
                'surat_izin_ortu'    => $pendaftaran->surat_izin_ortu,

                // Sesuaikan dengan nama kolom tabel siswas
                'dokumen_pendukung'  => $pendaftaran->kartu_pelajar,

                // ENUM tabel siswas
                'status_verifikasi'  => 'Diterima',

                'tanggal_daftar'     => now()->toDateString(),
                'created_at'         => now(),
                'updated_at'         => now(),
            ]);
        }

        // Update status pendaftaran
        DB::table('pendaftarans')
            ->where('id', $id)
            ->update([
                'status' => 'diterima'
            ]);

        return redirect()
            ->route('admin.pendaftaran')
            ->with('success', 'Siswa berhasil diterima.');
    }

    /**
     * Tolak pendaftaran siswa
     */
    public function tolak($id)
    {
        DB::table('pendaftarans')
            ->where('id', $id)
            ->update([
                'status' => 'ditolak'
            ]);

        return redirect()
            ->route('admin.pendaftaran')
            ->with('success', 'Pendaftaran berhasil ditolak.');
    }
}